from __future__ import annotations

import httpx2

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import path_template, strip_not_given
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.user_profiles.user_profile_action_url import UserProfileActionURL
from ...types.user_profiles.user_profile_enroll_end_user_action_param import UserProfileEnrollEndUserActionParam

__all__ = ["ActionURLs", "AsyncActionURLs"]


class ActionURLs(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ActionURLsWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/anthropics/anthropic-sdk-python#accessing-raw-response-data-eg-headers
        """
        return ActionURLsWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ActionURLsWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/anthropics/anthropic-sdk-python#with_streaming_response
        """
        return ActionURLsWithStreamingResponse(self)

    def create(
        self,
        user_profile_id: str,
        *,
        action: UserProfileEnrollEndUserActionParam,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> UserProfileActionURL:
        """
        Create Action URL

        Args:
          user_profile_id: The ID of the user profile the action is for (`uprof_...`).

          action: The action that the person who opens the URL takes.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not user_profile_id:
            raise ValueError(f"Expected a non-empty value for `user_profile_id` but received {user_profile_id!r}")
        extra_headers = {**strip_not_given({"anthropic-workspace-id": workspace_id}), **(extra_headers or {})}
        return self._post(
            path_template("/v1/user_profiles/{user_profile_id}/action_urls", user_profile_id=user_profile_id),
            body={"action": action},
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.user_profiles.action_urls.create",
                span_route="/v1/user_profiles/{user_profile_id}/action_urls",
                span_attributes={"anthropic.user_profile.id": user_profile_id},
            ),
            cast_to=UserProfileActionURL,
        )


class AsyncActionURLs(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncActionURLsWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/anthropics/anthropic-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncActionURLsWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncActionURLsWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/anthropics/anthropic-sdk-python#with_streaming_response
        """
        return AsyncActionURLsWithStreamingResponse(self)

    async def create(
        self,
        user_profile_id: str,
        *,
        action: UserProfileEnrollEndUserActionParam,
        workspace_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> UserProfileActionURL:
        """
        Create Action URL

        Args:
          user_profile_id: The ID of the user profile the action is for (`uprof_...`).

          action: The action that the person who opens the URL takes.

          workspace_id: Optional header to select the Workspace for this request. The value is a
              Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

              Only needed for credentials that can act on more than one Workspace. A
              credential that belongs to a specific Workspace may omit it; if sent, it must
              match that Workspace.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not user_profile_id:
            raise ValueError(f"Expected a non-empty value for `user_profile_id` but received {user_profile_id!r}")
        extra_headers = {**strip_not_given({"anthropic-workspace-id": workspace_id}), **(extra_headers or {})}
        return await self._post(
            path_template("/v1/user_profiles/{user_profile_id}/action_urls", user_profile_id=user_profile_id),
            body={"action": action},
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.user_profiles.action_urls.create",
                span_route="/v1/user_profiles/{user_profile_id}/action_urls",
                span_attributes={"anthropic.user_profile.id": user_profile_id},
            ),
            cast_to=UserProfileActionURL,
        )


class ActionURLsWithRawResponse:
    def __init__(self, action_urls: ActionURLs) -> None:
        self._action_urls = action_urls

        self.create = to_raw_response_wrapper(
            action_urls.create,
        )


class AsyncActionURLsWithRawResponse:
    def __init__(self, action_urls: AsyncActionURLs) -> None:
        self._action_urls = action_urls

        self.create = async_to_raw_response_wrapper(
            action_urls.create,
        )


class ActionURLsWithStreamingResponse:
    def __init__(self, action_urls: ActionURLs) -> None:
        self._action_urls = action_urls

        self.create = to_streamed_response_wrapper(
            action_urls.create,
        )


class AsyncActionURLsWithStreamingResponse:
    def __init__(self, action_urls: AsyncActionURLs) -> None:
        self._action_urls = action_urls

        self.create = async_to_streamed_response_wrapper(
            action_urls.create,
        )
