from __future__ import annotations

import httpx2

from ...._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ...._utils import path_template
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ....pagination import SyncPage, AsyncPage
from ...._base_client import AsyncPaginator, make_request_options
from ....types.organization import WorkspaceRole, NoBillingWorkspaceRole
from ....types.organization.workspace_role import WorkspaceRole
from ....types.organization.workspace_member import WorkspaceMember
from ....types.organization.no_billing_workspace_role import NoBillingWorkspaceRole
from ....types.organization.workspaces.member_remove_response import MemberRemoveResponse

__all__ = ["Members", "AsyncMembers"]


class Members(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> MembersWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/anthropics/anthropic-sdk-python#accessing-raw-response-data-eg-headers
        """
        return MembersWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> MembersWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/anthropics/anthropic-sdk-python#with_streaming_response
        """
        return MembersWithStreamingResponse(self)

    def retrieve(
        self,
        user_id: str,
        *,
        workspace_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> WorkspaceMember:
        """
        Get Workspace Member

        Args:
          workspace_id: ID of the Workspace.

          user_id: ID of the User.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        if not user_id:
            raise ValueError(f"Expected a non-empty value for `user_id` but received {user_id!r}")
        return self._get(
            path_template(
                "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
                workspace_id=workspace_id,
                user_id=user_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.workspaces.members.retrieve",
                span_route="/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
                span_attributes={
                    "anthropic.organization.workspace.id": workspace_id,
                    "anthropic.organization.workspace.member.id": user_id,
                },
            ),
            cast_to=WorkspaceMember,
        )

    def update(
        self,
        user_id: str,
        *,
        workspace_id: str,
        workspace_role: WorkspaceRole,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> WorkspaceMember:
        """
        Update Workspace Member

        Args:
          workspace_id: ID of the Workspace.

          user_id: ID of the User.

          workspace_role: New workspace role for the User.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        if not user_id:
            raise ValueError(f"Expected a non-empty value for `user_id` but received {user_id!r}")
        return self._post(
            path_template(
                "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
                workspace_id=workspace_id,
                user_id=user_id,
            ),
            body={"workspace_role": workspace_role},
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.workspaces.members.update",
                span_route="/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
                span_attributes={
                    "anthropic.organization.workspace.id": workspace_id,
                    "anthropic.organization.workspace.member.id": user_id,
                },
            ),
            cast_to=WorkspaceMember,
        )

    def list(
        self,
        workspace_id: str,
        *,
        after_id: str | Omit = omit,
        before_id: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> SyncPage[WorkspaceMember]:
        """
        List Workspace Members

        Args:
          workspace_id: ID of the Workspace.

          after_id: ID of the object to use as a cursor for pagination. When provided, returns the
              page of results immediately after this object.

          before_id: ID of the object to use as a cursor for pagination. When provided, returns the
              page of results immediately before this object.

          limit: Number of items to return per page.

              Defaults to `20`. Ranges from `1` to `1000`.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        return self._get_api_list(
            path_template("/v1/organizations/workspaces/{workspace_id}/members", workspace_id=workspace_id),
            page=SyncPage[WorkspaceMember],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query={
                    "after_id": after_id,
                    "before_id": before_id,
                    "limit": limit,
                },
                span_name="anthropic.organization.workspaces.members.list",
                span_route="/v1/organizations/workspaces/{workspace_id}/members",
                span_attributes={"anthropic.organization.workspace.id": workspace_id},
            ),
            model=WorkspaceMember,
        )

    def add(
        self,
        workspace_id: str,
        *,
        user_id: str,
        workspace_role: NoBillingWorkspaceRole,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> WorkspaceMember:
        """
        Create Workspace Member

        Args:
          workspace_id: ID of the Workspace.

          user_id: ID of the User.

          workspace_role: Role of the new Workspace Member. Cannot be `workspace_billing`.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        return self._post(
            path_template("/v1/organizations/workspaces/{workspace_id}/members", workspace_id=workspace_id),
            body={
                "user_id": user_id,
                "workspace_role": workspace_role,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.workspaces.members.add",
                span_route="/v1/organizations/workspaces/{workspace_id}/members",
                span_attributes={"anthropic.organization.workspace.id": workspace_id},
                span_created_id=("anthropic.organization.workspace.member.id", "user_id"),
            ),
            cast_to=WorkspaceMember,
        )

    def remove(
        self,
        user_id: str,
        *,
        workspace_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> MemberRemoveResponse:
        """
        Delete Workspace Member

        Args:
          workspace_id: ID of the Workspace.

          user_id: ID of the User.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        if not user_id:
            raise ValueError(f"Expected a non-empty value for `user_id` but received {user_id!r}")
        return self._delete(
            path_template(
                "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
                workspace_id=workspace_id,
                user_id=user_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.workspaces.members.remove",
                span_route="/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
                span_attributes={
                    "anthropic.organization.workspace.id": workspace_id,
                    "anthropic.organization.workspace.member.id": user_id,
                },
            ),
            cast_to=MemberRemoveResponse,
        )


class AsyncMembers(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncMembersWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/anthropics/anthropic-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncMembersWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncMembersWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/anthropics/anthropic-sdk-python#with_streaming_response
        """
        return AsyncMembersWithStreamingResponse(self)

    async def retrieve(
        self,
        user_id: str,
        *,
        workspace_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> WorkspaceMember:
        """
        Get Workspace Member

        Args:
          workspace_id: ID of the Workspace.

          user_id: ID of the User.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        if not user_id:
            raise ValueError(f"Expected a non-empty value for `user_id` but received {user_id!r}")
        return await self._get(
            path_template(
                "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
                workspace_id=workspace_id,
                user_id=user_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.workspaces.members.retrieve",
                span_route="/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
                span_attributes={
                    "anthropic.organization.workspace.id": workspace_id,
                    "anthropic.organization.workspace.member.id": user_id,
                },
            ),
            cast_to=WorkspaceMember,
        )

    async def update(
        self,
        user_id: str,
        *,
        workspace_id: str,
        workspace_role: WorkspaceRole,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> WorkspaceMember:
        """
        Update Workspace Member

        Args:
          workspace_id: ID of the Workspace.

          user_id: ID of the User.

          workspace_role: New workspace role for the User.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        if not user_id:
            raise ValueError(f"Expected a non-empty value for `user_id` but received {user_id!r}")
        return await self._post(
            path_template(
                "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
                workspace_id=workspace_id,
                user_id=user_id,
            ),
            body={"workspace_role": workspace_role},
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.workspaces.members.update",
                span_route="/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
                span_attributes={
                    "anthropic.organization.workspace.id": workspace_id,
                    "anthropic.organization.workspace.member.id": user_id,
                },
            ),
            cast_to=WorkspaceMember,
        )

    def list(
        self,
        workspace_id: str,
        *,
        after_id: str | Omit = omit,
        before_id: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[WorkspaceMember, AsyncPage[WorkspaceMember]]:
        """
        List Workspace Members

        Args:
          workspace_id: ID of the Workspace.

          after_id: ID of the object to use as a cursor for pagination. When provided, returns the
              page of results immediately after this object.

          before_id: ID of the object to use as a cursor for pagination. When provided, returns the
              page of results immediately before this object.

          limit: Number of items to return per page.

              Defaults to `20`. Ranges from `1` to `1000`.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        return self._get_api_list(
            path_template("/v1/organizations/workspaces/{workspace_id}/members", workspace_id=workspace_id),
            page=AsyncPage[WorkspaceMember],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query={
                    "after_id": after_id,
                    "before_id": before_id,
                    "limit": limit,
                },
                span_name="anthropic.organization.workspaces.members.list",
                span_route="/v1/organizations/workspaces/{workspace_id}/members",
                span_attributes={"anthropic.organization.workspace.id": workspace_id},
            ),
            model=WorkspaceMember,
        )

    async def add(
        self,
        workspace_id: str,
        *,
        user_id: str,
        workspace_role: NoBillingWorkspaceRole,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> WorkspaceMember:
        """
        Create Workspace Member

        Args:
          workspace_id: ID of the Workspace.

          user_id: ID of the User.

          workspace_role: Role of the new Workspace Member. Cannot be `workspace_billing`.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        return await self._post(
            path_template("/v1/organizations/workspaces/{workspace_id}/members", workspace_id=workspace_id),
            body={
                "user_id": user_id,
                "workspace_role": workspace_role,
            },
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.workspaces.members.add",
                span_route="/v1/organizations/workspaces/{workspace_id}/members",
                span_attributes={"anthropic.organization.workspace.id": workspace_id},
                span_created_id=("anthropic.organization.workspace.member.id", "user_id"),
            ),
            cast_to=WorkspaceMember,
        )

    async def remove(
        self,
        user_id: str,
        *,
        workspace_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> MemberRemoveResponse:
        """
        Delete Workspace Member

        Args:
          workspace_id: ID of the Workspace.

          user_id: ID of the User.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not workspace_id:
            raise ValueError(f"Expected a non-empty value for `workspace_id` but received {workspace_id!r}")
        if not user_id:
            raise ValueError(f"Expected a non-empty value for `user_id` but received {user_id!r}")
        return await self._delete(
            path_template(
                "/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
                workspace_id=workspace_id,
                user_id=user_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                span_name="anthropic.organization.workspaces.members.remove",
                span_route="/v1/organizations/workspaces/{workspace_id}/members/{user_id}",
                span_attributes={
                    "anthropic.organization.workspace.id": workspace_id,
                    "anthropic.organization.workspace.member.id": user_id,
                },
            ),
            cast_to=MemberRemoveResponse,
        )


class MembersWithRawResponse:
    def __init__(self, members: Members) -> None:
        self._members = members

        self.retrieve = to_raw_response_wrapper(
            members.retrieve,
        )
        self.update = to_raw_response_wrapper(
            members.update,
        )
        self.list = to_raw_response_wrapper(
            members.list,
        )
        self.add = to_raw_response_wrapper(
            members.add,
        )
        self.remove = to_raw_response_wrapper(
            members.remove,
        )


class AsyncMembersWithRawResponse:
    def __init__(self, members: AsyncMembers) -> None:
        self._members = members

        self.retrieve = async_to_raw_response_wrapper(
            members.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            members.update,
        )
        self.list = async_to_raw_response_wrapper(
            members.list,
        )
        self.add = async_to_raw_response_wrapper(
            members.add,
        )
        self.remove = async_to_raw_response_wrapper(
            members.remove,
        )


class MembersWithStreamingResponse:
    def __init__(self, members: Members) -> None:
        self._members = members

        self.retrieve = to_streamed_response_wrapper(
            members.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            members.update,
        )
        self.list = to_streamed_response_wrapper(
            members.list,
        )
        self.add = to_streamed_response_wrapper(
            members.add,
        )
        self.remove = to_streamed_response_wrapper(
            members.remove,
        )


class AsyncMembersWithStreamingResponse:
    def __init__(self, members: AsyncMembers) -> None:
        self._members = members

        self.retrieve = async_to_streamed_response_wrapper(
            members.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            members.update,
        )
        self.list = async_to_streamed_response_wrapper(
            members.list,
        )
        self.add = async_to_streamed_response_wrapper(
            members.add,
        )
        self.remove = async_to_streamed_response_wrapper(
            members.remove,
        )
